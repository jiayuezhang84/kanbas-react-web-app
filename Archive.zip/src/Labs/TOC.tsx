import { useLocation } from "react-router";
//href="https://github.com/jiayuezhang84"
export default function TOC() {
    const { pathname } = useLocation();
    return (
        <ul className="nav nav-pills" id="wd-toc">
            <li className="nav-item"><a id="wd-a" href="#/Labs" className="nav-link">Labs</a></li>
            <li className="nav-item"><a id="wd-a1" href="#/Labs/Lab1"
                className={`nav-link ${pathname.includes("Lab1") ? "active" : ""}`}>Lab 1</a></li>
            <li className="nav-item"><a id="wd-a2" href="#/Labs/Lab2"
                className={`nav-link ${pathname.includes("Lab2") ? "active" : ""}`}>Lab 2</a></li>
            <li className="nav-item"><a id="wd-a3" href="#/Labs/Lab3"
                className={`nav-link ${pathname.includes("Lab3") ? "active" : ""}`}>Lab 3</a></li>
            <li className="nav-item"><a id="wd-a4" href="#/Labs/Lab4"
                className={`nav-link ${pathname.includes("Lab4") ? "active" : ""}`}>Lab 4</a></li>
            <li className="nav-item"><a id="wd-a5" href="#/Labs/Lab5" 
                className={`nav-link ${pathname.includes("Lab5") ? "active" : ""}`}>Lab 5</a></li>
            <li className="nav-item"><a id="wd-k" href="#/Kanbas" className="nav-link">Kanbas</a></li>
            <li className="nav-item"><a id="wd-github" href="https://github.com/jiayuezhang84" target="_blank"
                className="nav-link">My GitHub</a></li>
            <li className="nav-item"><a id="wd-repo" href="https://github.com/jiayuezhang84/kanbas-node-server-app" target="_blank"
                className="nav-link">New GitHub Repo</a></li>
            <li className="nav-item"><a id="wd-render" href="https://kanbas-node-server-app-xil0.onrender.com" target="_blank"
                className="nav-link">Render</a></li>
            <li className="nav-item"><a id="wd-heroku" href="https://kanbas-node-server-app-jz-91bd5968bfcb.herokuapp.com/" target="_blank"
                className="nav-link">Heroku</a></li>
        </ul>
    );
}


